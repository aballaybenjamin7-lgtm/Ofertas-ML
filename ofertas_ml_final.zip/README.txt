# Ofertas ML
Sitio estático listo para publicar gratis con GitHub Pages.

## Publicación
1. Crear un repositorio llamado `ofertas-ml`.
2. Subir `index.html` a la raíz.
3. GitHub → Settings → Pages.
4. Source: Deploy from a branch → `main` → `/ (root)` → Save.

## Editar productos
Abrí `index.html` y buscá `const products=[...`.
Podés cambiar título, categoría, precio, emoji y enlace.

Importante: verificá precios, disponibilidad y condiciones directamente en Mercado Libre.
